from django.test import TestCase

# Create your tests here.
import time
import pyautogui
import webbrowser

while True:
    time.sleep(50)

    # Move the mouse cursor to a specific position
    pyautogui.moveTo(100, 100, duration=1)

    # Perform mouse actions (e.g., click, drag, etc.) as needed
    pyautogui.dragRel(50, 50, duration=2)
    # pyautogui.dragRel(0, 100, duration=1)
    # pyautogui.dragRel(-100, 100, duration=1)
    # pyautogui.dragRel(0, 100, duration=1)

    # Open a new website in the default web browser
    # url = "file:///C:/Users/dell/Downloads/Generating%20Chassis%20Number%20from%20VIN.pdf.pdf"  # Replace with the URL you want to open
    # webbrowser.open(url)

    time.sleep(10)

